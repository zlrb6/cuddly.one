<!DOCTYPE html>
<html>

<head>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title> أجير - AJeer</title>
<link rel="icon" type="image/png" href="img/ww.png">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="Asset/style.css">
<link rel="stylesheet" href="Asset/w3.css">
 <script type="text/javascript" src=""></script>
   
<script src="https://kit.fontawesome.com/a538ef76bd.js" crossorigin="anonymous"></script>
<style>

   </style>

  </head>

  <body>
    <div class="w3-sidebar w3-bar-block w3-dark-grey w3-animate-left" style="display:none" id="mySidebar">

     
      <button class="w3-bar-item w3-button w3-large"style="background-color:#02a258"onclick="w3_close()">أغلاق &times;</button>
     <div>
     <a href="/Homes.html" class="w3-bar-item w3-button">الصفحة الرئيسية</a>
      <a href="/aboutUs.html" class="w3-bar-item w3-button">من نحن</a>
      <a href="/termsAndCondition.html" class="w3-bar-item w3-button">الشروط والأحكام</a>
    </div>
  </div>
    <header class="headerlist">
      <img alt="Ajeer"src="/img/logo.png"width="118px"height="94px">
<div class="iconlist" id="showList"><button type="button"onclick="w3_open()"style="cursor:pointer;background-color:white;border:none"><i class="fa fa-bars fa-2x icn" aria-hidden="true"></i></button></div>
</header>

<div class="line"></div><!----line-->
<!--slide show -->
<div class="slideShowbg">

  <div class="slideshow">
         
    <img class="mySlide w3-animate-left"width="677"height="142px" src="/img/Ajer1_1.jpg"alt="Image_one">
    <img class="mySlide w3-animate-left"width="677"height="142px" src="/img/Ajer2_2.jpg"alt="Image_two">
    <img class="mySlide w3-animate-left"width="677"height="142px" src="/img/Ajer3_3.jpg"alt="Image_two">
    <img class="mySlide w3-animate-left"width="677"height="142px" src="/img/Ajer4_4.jpg"alt="Image_two">
    <img class="mySlide w3-animate-left"width="677"height="142px" src="/img/Ajer5_5.jpg"alt="Image_two">
    <img class="mySlide w3-animate-left"width="677"height="142px" src="/img/Ajer6.jfif"alt="Image_two">

    </div>

</div>
<!----slide show image-->
<br>
<!------from begin-------->
<div class="containerForm">
<div class="msg">
    </div>

<form class="form" action="/contactus.php" method="POST">
<label>ادخل اسمك :</label>
<br>
<input class="inpa" type="text"placeholder="type here..."required>
<br>
<label>ادخل بريدك الإلكتروني :</label>
<br>
<input class="inpa" type="email"placeholder="example@email.com"required>
   <br>
   <label>الموضوع :</label>
<br>
<input class="inpa" type="text"placeholder="subject">
   <br>
   <label>اكتب رسالتك :</label>
  <br>
  <textarea class="inpa" type="textarea"placeholder="your massege here..."style="height: 150px;resize: none;justify-self: unset;"></textarea>
  <br>
   <input type="submit"name="submit"value="أرسل"id="next">


</form>

<!------from End-------->

</div>

<footer>
<div class="footContainer">
<img alt="footerimg"src="/img/footerLogo.png"width="100px"height="75px">
<div class="footP">
<p>2014-2022 كل الحقوق محفوظة لخدمة ®أجير</p>
<p>All rights reserved to ®Ajeer service 2014-2022</p>
</div>

</div>
<div class="info">
  
 <P>AjeerSA &nbsp;<i class="fa fa-phone fa-lg" aria-hidden="true"></i></P>

 <P>920011040  &nbsp;<i class="fa fa-envelope fa-lg" aria-hidden="true"></i></P>

 <P>ajeer-sa@email.com  &nbsp;<i class="fa fa-twitter-square fa-lg" aria-hidden="true"></i></P>



</div>

</footer>
<!-------------script--------------->

<script type="text/javascript" src="javascript/sideBar.js"></script>
<script src="/javascript/slideShowImage.js"></script>
<script type="text/javascript" src="/javascript/stop.js"></script>

<!-------------script--------------->

  </body>

  </html>